

public class ExpressionTree {
    private Node root;

    public ExpressionTree() { // constructor for ExpressionTree
        this.root = null;
    }

    public void buildTree(String postfix) {
        ArrayStack<Node> stack = new ArrayStack<>();  // Using ArrayStack here for hw
        String[] tokens = postfix.split(" "); // splitting the postfix expression into tokens


        for (String token : tokens) { // process each token in the postfix expression
            if (isNumeric(token)) {
                stack.push(new Node(token));
            } else {
                Node right = stack.pop();
                Node left = stack.pop();
                stack.push(new Node(token, left, right));
            }
        }

        this.root = stack.pop();
    }

    private boolean isNumeric(String str) { // helper method to check if string is numeric
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) { //If an exception occurs, string is not numeric
            return false;
        }
    }

    public String prefix() { //use StringBuilder
        StringBuilder sb = new StringBuilder();
        prefix(this.root, sb);
        return sb.toString().trim();
    }

    private void prefix(Node node, StringBuilder sb) {
        if (node != null) {
            sb.append(node.element);
            prefix(node.leftChild, sb);
            prefix(node.rightChild, sb);
        }
    }

    public String infix() { // same way
        StringBuilder sb = new StringBuilder(); 
        infix(this.root, sb);
        return sb.toString().trim();
    }

    private void infix(Node node, StringBuilder sb) { 
        if (node == null) {
            return;
        }

        sb.append("("); // Add an opening parenthesis for each node, number or operator

        if (node.leftChild == null && node.rightChild == null) {
            sb.append(node.element); // If its a leaf, add the number
        } else {
            infix(node.leftChild, sb);
            sb.append(node.element);  // This is the operator
            infix(node.rightChild, sb);
        }

        sb.append(")"); // must add a closing parenthesis for each node
    }

    public String postfix() {
        StringBuilder sb = new StringBuilder(); // use StringBuilder to build my postfix expression
        postfix(this.root, sb);
        return sb.toString().trim();
    }

    private void postfix(Node node, StringBuilder sb) { // Recursive method so I can construct the prefix expression
        if (node != null) {
            postfix(node.leftChild, sb);
            postfix(node.rightChild, sb);
            sb.append(node.element);
        }
    }
}