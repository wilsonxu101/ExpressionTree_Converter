

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        while (true) { // Students should ensure that their input method can run indefinitely and only exiting the console/terminal (Ctrl+C) should exit the program.
            System.out.println("Type your expression:");
            String expression = input.nextLine();
            
            // Creating objects of the Converter and ExpressionTree classes
            Converter converter = new Converter(expression);
            String postfix = converter.toPostFix();

            ExpressionTree expressionTree = new ExpressionTree();
            expressionTree.buildTree(postfix);

            System.out.println("Prefix: " + expressionTree.prefix()); // printing my results 
            System.out.println("Infix: " + expressionTree.infix());
            System.out.println("Postfix: " + expressionTree.postfix());
        }
    }
}
